# Lab Sains Data — Kelompok 7

Proyek: **Prioritas mitigasi banjir dan tanah longsor di Jawa Tengah**

Keputusan yang dikaji: kabupaten/kota mana yang didahulukan dalam program mitigasi, berdasarkan frekuensi kejadian atau dampak per penduduk.

## Struktur
- `p8/01_lembar_rencana_data.md` — bingkai keputusan dan rencana data
- `p8/02_lembar_verifikasi_sumber.md` — hasil cek sumber (diisi manual)
- `p8/03_README_data.md` — asal-usul data
- `p8/04_log_ai.md` — catatan pemakaian AI
- `data/raw/` — data mentah (jangan diubah)

Status: P8 (draf, sumber belum diverifikasi)

# Lembar Rencana Data — P8

**Judul proyek:** Penentuan Prioritas Wilayah Mitigasi Banjir dan Tanah Longsor di Jawa Tengah Berbasis Data Kejadian dan Dampak per Penduduk

**Kalimat keputusan:** Tim perencana mitigasi bencana tingkat provinsi (setara BPBD Jateng) perlu memutuskan wilayah prioritas program mitigasi banjir dan longsor, antara pilihan A, B, atau tetap seperti sekarang, sebelum penyusunan anggaran tahun berikutnya. Angka yang paling membedakan pilihan itu adalah dampak bencana per 100.000 penduduk.

| Baris | Isi |
|---|---|
| **KEPUTUSAN** | Tim perencana mitigasi memilih 5 kabupaten/kota prioritas sebelum penyusunan anggaran tahun depan |
| **PILIHAN** | A: prioritas menurut jumlah kejadian banjir + longsor terbanyak. B: prioritas menurut dampak per 100.000 penduduk (korban terdampak + rumah rusak). C: tetap seperti sekarang (alokasi merata) |
| **ANGKA PEMBEDA** | Dampak per 100.000 penduduk per kabupaten/kota, rata-rata 2020–2025 |
| **AMBANG** | Pilih B bila minimal 2 dari 5 kabupaten/kota teratas menurut dampak per penduduk tidak masuk 5 teratas menurut jumlah kejadian. Bila kurang dari 2, pilih A (peringkatnya mirip, hitungan lebih sederhana) |
| **DATA** | Kejadian, korban, dan rumah rusak per kabupaten/kota per tahun; jumlah penduduk per kabupaten/kota |
| **SUMBER KANDIDAT** | 1) DIBI BNPB (dibi.bnpb.go.id) 2) BPS Provinsi Jawa Tengah (penduduk per kabupaten/kota) 3) Satu Data Jawa Tengah (pembanding data BPBD) |
| **UBAH PILIHAN?** | Kejadian dan dampak (DIBI): **Ya**. Penduduk (BPS): **Ya**, tanpa ini dampak per kapita tidak bisa dihitung. Curah hujan BMKG: **Tidak untuk keputusan ini**, dicoret dulu (bisa dipakai di tahap diagnostik P11) |
| **LAMPU DATA** | Hijau (data agregat terbuka, tanpa identitas orang) |
| **JIKA TIDAK ADA** | Bila DIBI gagal diunduh: pakai buletin bulanan BNPB atau data BPBD Jateng di Satu Data Jawa Tengah |

**Jenis analitik:** deskriptif (rekap per wilayah) menuju preskriptif (pilih prioritas).
**Catatan:** cocokkan dengan produk kelompok di Lab Pemrograman bila dosen memintanya.

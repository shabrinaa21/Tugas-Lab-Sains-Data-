# README_data

SUMBER          : DIBI BNPB (dibi.bnpb.go.id) — diisi setelah diunduh
TANGGAL AMBIL   : [isi]
CARA AMBIL      : unduh manual dari situs
PARAMETER       : provinsi Jawa Tengah; jenis banjir dan tanah longsor; 2020–2025; per kabupaten/kota
JUMLAH BARIS    : mentah [n] → bersih [n]
LISENSI/ATURAN  : [cek di situs sumber]
ANONIMISASI     : tidak ada kolom identitas orang (data agregat)
AI YANG DIPAKAI : lihat 04_log_ai.md
VALIDASI        : diisi di P9
KETERBATASAN    : data DIBI bergantung pada laporan daerah; kejadian kecil bisa tidak tercatat

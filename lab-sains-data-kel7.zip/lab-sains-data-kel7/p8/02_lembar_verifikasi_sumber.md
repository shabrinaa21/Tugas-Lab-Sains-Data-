# Lembar Verifikasi Sumber — P8

Diisi manual setelah membuka setiap tautan. Jangan isi dari ingatan atau dari jawaban AI.

| # | Sumber | Tautan | Penerbit | Tanggal pembaruan | Lisensi/aturan | Ada data pribadi? | Data bisa diunduh? | Putusan (pakai/cek/tolak) |
|---|---|---|---|---|---|---|---|---|
| 1 | DIBI BNPB | dibi.bnpb.go.id | | | | | | |
| 2 | BPS Jawa Tengah | jateng.bps.go.id | | | | | | |
| 3 | Satu Data Jawa Tengah | | | | | | | |
| 4 | InaRISK BNPB (pembanding) | | | | | | | |
| 5 | BMKG Data Online (dicoret, cadangan) | | | | | | | |

**Usulan AI yang salah:** ___ dari ___ usulan = ___ %
(hitung setelah semua tautan dibuka)
